﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Name_Search
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkButton_Click(object sender, EventArgs e)
        {

            //I did both extra credits to the best of my ability. I was a little lost and I would like the code solution.

            
            
            try
            {

                popularityResultLabel.Text = ""; //Clears text after each input


                StreamReader names; // StreamReader variable
                names = File.OpenText("Names.Txt"); // Using Streamreader to open file
                //I put the streamreader on top so it could only be extracted once into the array. I could be wrong though.

                // array variable
                const int SIZE = 400; // size of the array
                string[] namesArray = new string[SIZE]; // array that holds file
                int testVar = 0; // Text variable to make the output accurate

              

                //counter variable 
                int i = 0;

                
                while (i < namesArray.Length && !names.EndOfStream) //goes through each item in the list while stopping at the end until the result is found
                {
                  
                    namesArray[i] = names.ReadLine(); // equals the names read in the line

                    if(nameTextBox.Text == namesArray[i]) //To test if name is in the list
                    {
                        // if the name is in the list
                        popularityResultLabel.Text = "This name IS popular!";
                        testVar = 1; // test variable is set to one if name is in the list
                    }
                  
                }

                if (testVar == 0) // To test if name is not in the list, conditional is outside loop with test variable
                {
                    // if the name is not in the list
                    popularityResultLabel.Text = "Sorry, this name IS NOT popular!";
                    // test variable remains zero
                }

                if (nameTextBox.Text == "")// if there is no input in the textbox
                {
                    //Label result if there is no input in the text
                    popularityResultLabel.Text = "No Input Provided";
                }
               

            }
            catch (Exception ex)
            {
                //display an error meesage if file is not found
                MessageBox.Show(ex.Message);
            }

           
        }
        

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
